require_extension('F');
require_fp;
WRITE_FRD(fsgnj32(FRS1, FRS2, false, true));
